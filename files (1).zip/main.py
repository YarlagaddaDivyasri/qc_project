import math, random, uuid
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

app = FastAPI(title="Waste Route Optimizer")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

DEPOT = {"name": "Depot", "x": 50.0, "y": 50.0}


class BinIn(BaseModel):
    name: str
    x: float = Field(ge=0, le=100)
    y: float = Field(ge=0, le=100)
    fill: int = Field(50, ge=0, le=100)


class OptimizeIn(BaseModel):
    threshold: int = 60      # only bins filled at least this much are collected
    iterations: int = 4000
    mode: str = "priority"   # priority | balanced | shortest


BINS: dict = {}


def add(name, x, y, fill):
    bid = uuid.uuid4().hex[:8]
    BINS[bid] = {"id": bid, "name": name, "x": x, "y": y, "fill": fill}


for n, x, y, f in [("Market St", 20, 25, 85), ("Central Park", 75, 20, 40), ("Bus Stand", 82, 68, 92),
                   ("School Rd", 30, 75, 70), ("Lake View", 60, 85, 55), ("Hospital", 15, 50, 95),
                   ("Old Town", 45, 15, 78)]:
    add(n, x, y, f)


# ---------- CRUD for bins ----------
@app.get("/api/bins")
def list_bins():
    return list(BINS.values())


@app.post("/api/bins")
def create_bin(b: BinIn):
    add(b.name, b.x, b.y, b.fill)
    return list(BINS.values())[-1]


@app.put("/api/bins/{bid}")
def update_bin(bid: str, b: BinIn):
    if bid not in BINS:
        raise HTTPException(404, "Bin not found")
    BINS[bid] = {"id": bid, **b.model_dump()}
    return BINS[bid]


@app.delete("/api/bins/{bid}")
def delete_bin(bid: str):
    if BINS.pop(bid, None) is None:
        raise HTTPException(404, "Bin not found")
    return {"deleted": bid}


# ---------- Route optimization ----------
def dist(a, b):
    return math.hypot(a["x"] - b["x"], a["y"] - b["y"])


def closed_len(order, pts):
    return sum(dist(pts[order[i]], pts[order[(i + 1) % len(order)]]) for i in range(len(order)))


def priority_cost(order, pts):
    """Fuller bins should be reached earlier: sum(fill x distance travelled so far),
    plus a small weight on the total loop length."""
    travelled, delay = 0.0, 0.0
    for a, b in zip(order, order[1:]):
        travelled += dist(pts[a], pts[b])
        delay += pts[b].get("fill", 0) / 100 * travelled
    return delay + 0.2 * closed_len(order, pts)


def anneal(order, pts, iters, cost):
    """Quantum-inspired optimizer: simulated annealing with 2-opt moves
    (classical stand-in for QAOA; index 0 = depot stays first)."""
    best = cur = order[:]
    best_c = cur_c = cost(cur)
    t0 = max(cur_c / len(pts), 1e-6)
    for k in range(iters):
        if len(cur) < 4:
            break
        t = t0 * (1 - k / iters) + 1e-6
        i, j = sorted(random.sample(range(1, len(cur)), 2))
        cand = cur[:i] + cur[i:j + 1][::-1] + cur[j + 1:]
        cc = cost(cand)
        if cc < cur_c or random.random() < math.exp((cur_c - cc) / t):
            cur, cur_c = cand, cc
            if cc < best_c:
                best, best_c = cand[:], cc
    return best


@app.post("/api/optimize")
def optimize(req: OptimizeIn):
    chosen = [b for b in BINS.values() if b["fill"] >= req.threshold]
    if not chosen:
        return {"route": [], "baseline": 0, "optimized": 0, "saving_pct": 0, "stops": 0}
    pts = [DEPOT] + chosen
    base_len = closed_len(list(range(len(pts))), pts)      # visiting bins in list order
    if req.mode == "priority":                             # strict: highest fill first
        order = [0] + sorted(range(1, len(pts)), key=lambda i: -pts[i]["fill"])
    elif req.mode == "shortest":
        start = sorted(range(1, len(pts)), key=lambda i: dist(DEPOT, pts[i]))
        cost = lambda o: closed_len(o, pts)
    else:                                                  # "balanced": fuller early, but keep it short
        start = sorted(range(1, len(pts)), key=lambda i: -pts[i]["fill"])
        cost = lambda o: priority_cost(o, pts)
    if req.mode != "priority":
        order = anneal([0] + start, pts, req.iterations, cost)
    opt_len = closed_len(order, pts)
    route = [{"name": pts[i]["name"], "x": pts[i]["x"], "y": pts[i]["y"], "fill": pts[i].get("fill")} for i in order]
    saving = 100 * (base_len - opt_len) / base_len if base_len else 0
    return {"route": route, "baseline": round(base_len, 1), "optimized": round(opt_len, 1),
            "saving_pct": round(saving, 1), "stops": len(chosen)}
