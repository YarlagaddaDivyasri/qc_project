import { useEffect, useState } from "react";

const API = import.meta.env.VITE_API_URL || "http://localhost:8001";
const api = (path, opts = {}) =>
  fetch(API + path, { headers: { "Content-Type": "application/json" }, ...opts }).then((r) => r.json());

const color = (f) => (f >= 80 ? "#ff6b57" : f >= 60 ? "#f2b84b" : "#4fd1a5");

export default function App() {
  const [bins, setBins] = useState([]);
  const [threshold, setThreshold] = useState(60);
  const [result, setResult] = useState(null);
  const [busy, setBusy] = useState(false);
  const [mode, setMode] = useState("priority");
  const [error, setError] = useState("");

  const load = () =>
    api("/api/bins").then((d) => { setBins(d); setError(""); }).catch(() => setError("Backend not reachable. Start it on port 8001."));
  useEffect(() => { load(); }, []);

  const addBin = async (e) => {
    const r = e.currentTarget.getBoundingClientRect();
    const x = Math.round(((e.clientX - r.left) / r.width) * 100);
    const y = Math.round(((e.clientY - r.top) / r.height) * 100);
    await api("/api/bins", { method: "POST", body: JSON.stringify({ name: `Bin ${bins.length + 1}`, x, y, fill: 70 }) });
    setResult(null); load();
  };
  const update = async (b, patch) => {
    const nb = { ...b, ...patch };
    setBins(bins.map((x) => (x.id === b.id ? nb : x)));
    await api(`/api/bins/${b.id}`, { method: "PUT", body: JSON.stringify(nb) });
    setResult(null);
  };
  const remove = async (id) => { await api(`/api/bins/${id}`, { method: "DELETE" }); setResult(null); load(); };
  const optimize = async () => {
    setBusy(true);
    setResult(await api("/api/optimize", { method: "POST", body: JSON.stringify({ threshold, mode }) }));
    setBusy(false);
  };

  const path = result?.route?.length ? result.route.map((p) => `${p.x},${p.y}`).join(" ") + ` ${result.route[0].x},${result.route[0].y}` : "";

  return (
    <div className="app">
      <header>
        <h1>Waste Route Optimizer</h1>
        <p>Quantum-inspired waste collection routing for smart cities. Click the map to add a bin.</p>
      </header>
      {error && <div className="error">{error}</div>}

      <main>
        <section className="map-wrap">
          <svg viewBox="0 0 100 100" onClick={addBin} className="map">
            {[...Array(9)].map((_, i) => (
              <g key={i}><line x1={(i + 1) * 10} y1="0" x2={(i + 1) * 10} y2="100" /><line x1="0" y1={(i + 1) * 10} x2="100" y2={(i + 1) * 10} /></g>
            ))}
            {path && <polyline points={path} className="route" />}
            {bins.map((b) => (
              <circle key={b.id} cx={b.x} cy={b.y} r={1 + b.fill / 50} fill={color(b.fill)} opacity={b.fill >= threshold ? 1 : 0.35}
                onClick={(e) => e.stopPropagation()}><title>{b.name} · {b.fill}%</title></circle>
            ))}
            {result?.route?.slice(1).map((p, i) => (
              <text key={i} x={p.x + 2.2} y={p.y - 2} fontSize="4" fill="#fff" fontWeight="700">{i + 1}</text>
            ))}
            <rect x="47.5" y="47.5" width="5" height="5" className="depot" onClick={(e) => e.stopPropagation()}><title>Depot</title></rect>
          </svg>
        </section>

        <aside>
          <div className="panel">
            <label>Collect bins filled at least <b>{threshold}%</b></label>
            <input type="range" min="0" max="100" value={threshold} onChange={(e) => { setThreshold(+e.target.value); setResult(null); }} />
            <label style={{ marginTop: 12 }}>Route order</label>
            <select value={mode} onChange={(e) => { setMode(e.target.value); setResult(null); }}>
              <option value="priority">Fullest bins first</option>
              <option value="balanced">Balanced (full bins early, shorter path)</option>
              <option value="shortest">Shortest distance</option>
            </select>
            <button onClick={optimize} disabled={busy}>{busy ? "Optimizing…" : "Optimize route"}</button>
            {result && (
              <p className="stats">
                {result.stops} stops · {result.baseline} → <b>{result.optimized}</b> units
                {result.saving_pct > 0 && <span className="save">{result.saving_pct}% shorter than list order</span>}
              </p>
            )}
            {result?.route?.length > 0 && <ol className="order">{result.route.map((p, i) => <li key={i}>{p.name}{p.fill != null && ` (${p.fill}% full)`}</li>)}</ol>}
          </div>

          <div className="panel">
            <h2>Bins</h2>
            {bins.length === 0 && <p className="muted">No bins yet. Click the map to add one.</p>}
            {bins.map((b) => (
              <div className="bin" key={b.id}>
                <input value={b.name} onChange={(e) => update(b, { name: e.target.value })} />
                <input type="range" min="0" max="100" value={b.fill} onChange={(e) => update(b, { fill: +e.target.value })} />
                <span style={{ color: color(b.fill) }}>{b.fill}%</span>
                <button className="ghost" onClick={() => remove(b.id)} aria-label={`Delete ${b.name}`}>Delete</button>
              </div>
            ))}
          </div>
        </aside>
      </main>
    </div>
  );
}
